import os
import shutil
import random
from collections import defaultdict

def redistribute_by_graph_type():
    """
    Redistribute data by graph type for performance comparison
    Each graph type gets its own 70-15-15 split with all letters A-J
    """
    
    # Paths
    base_dir = "C:/Users/Teamaerosal/Desktop/data_new"
    led_off_dir = os.path.join(base_dir, "led_off")
    led_on_dir = os.path.join(base_dir, "led_on")
    
    # Valid Braille letters only
    valid_letters = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'}
    
    # Expected graph types (based on your states)
    expected_graph_types = {
        'dir_spike_count',     # NEW: unweighted directed spike count
        'dir_spike_count_w',   # weighted directed spike count  
        'dir_time',            # directed time-based
        'undir_spike_count',   # unweighted undirected spike count
        'undir_spike_count_w'  # weighted undirected spike count
    }
    
    # Collect files by graph type and letter
    files_by_graph_and_letter = defaultdict(lambda: defaultdict(list))
    skipped_files = []
    
    # Process both LED directories
    for led_subdir, led_status in [('led_off', 'off'), ('led_on', 'on')]:
        led_dir = os.path.join(base_dir, led_subdir)
        if not os.path.exists(led_dir):
            print(f"Warning: {led_dir} not found")
            continue
            
        for filename in os.listdir(led_dir):
            if not filename.endswith('.pt'):
                continue
                
            # Parse filename: trial_X_events_STATUS_LETTER_GRAPHTYPE.pt
            parts = filename.split('_')
            if len(parts) < 6:
                skipped_files.append(f"Invalid format: {filename}")
                continue
                
            letter = parts[4]
            # Graph type is everything from parts[5] onwards, joined back with underscores
            graph_type = '_'.join(parts[5:]).replace('.pt', '')
            
            # Filter valid letters and graph types
            if letter not in valid_letters:
                skipped_files.append(f"Invalid letter '{letter}': {filename}")
                continue
                
            if graph_type not in expected_graph_types:
                skipped_files.append(f"Unknown graph type '{graph_type}': {filename}")
                continue
            
            # Store file info
            files_by_graph_and_letter[graph_type][letter].append((led_subdir, filename))
    
    # Print collection summary
    print("="*60)
    print("FILE COLLECTION SUMMARY")
    print("="*60)
    
    total_files = 0
    for graph_type in sorted(expected_graph_types):
        print(f"\nGraph type: {graph_type}")
        graph_total = 0
        
        for letter in sorted(valid_letters):
            file_count = len(files_by_graph_and_letter[graph_type][letter])
            graph_total += file_count
            total_files += file_count
            print(f"  Letter {letter}: {file_count} files")
        
        print(f"  Subtotal: {graph_total} files")
    
    print(f"\nTotal valid files: {total_files}")
    
    if skipped_files:
        print(f"\nSkipped files ({len(skipped_files)}):")
        for skip_msg in skipped_files[:10]:  # Show first 10
            print(f"  {skip_msg}")
        if len(skipped_files) > 10:
            print(f"  ... and {len(skipped_files) - 10} more")
    
    # Create splits for each graph type
    print("\n" + "="*60)
    print("CREATING GRAPH-SPECIFIC SPLITS")
    print("="*60)
    
    for graph_type in sorted(expected_graph_types):
        print(f"\nProcessing graph type: {graph_type}")
        
        # Create directories for this graph type
        graph_base_dir = os.path.join(base_dir, f"data_{graph_type}")
        split_dirs = {
            'train': os.path.join(graph_base_dir, "train", "processed"),
            'val': os.path.join(graph_base_dir, "val", "processed"),
            'test': os.path.join(graph_base_dir, "test", "processed")
        }
        
        for split_dir in split_dirs.values():
            os.makedirs(split_dir, exist_ok=True)
        
        # Collect all files for this graph type
        all_files_for_graph = []
        letters_found = []
        
        for letter in sorted(valid_letters):
            letter_files = files_by_graph_and_letter[graph_type][letter]
            if letter_files:
                all_files_for_graph.extend([(letter, src_dir, filename) for src_dir, filename in letter_files])
                letters_found.append(letter)
        
        if not all_files_for_graph:
            print(f"  No files found for {graph_type}")
            continue
        
        print(f"  Letters found: {letters_found}")
        print(f"  Total files: {len(all_files_for_graph)}")
        
        # Shuffle for random distribution
        random.shuffle(all_files_for_graph)
        
        # Calculate split sizes (70-15-15)
        total_files_graph = len(all_files_for_graph)
        train_count = int(0.70 * total_files_graph)
        val_count = int(0.15 * total_files_graph)
        test_count = total_files_graph - train_count - val_count
        
        print(f"  Split: {train_count} train + {val_count} val + {test_count} test")
        
        # Assign files to splits
        splits = {
            'train': all_files_for_graph[:train_count],
            'val': all_files_for_graph[train_count:train_count + val_count],
            'test': all_files_for_graph[train_count + val_count:]
        }
        
        # Copy files and track letter distribution
        split_letter_counts = defaultdict(lambda: defaultdict(int))
        
        for split_name, file_list in splits.items():
            dest_dir = split_dirs[split_name]
            
            for letter, src_subdir, filename in file_list:
                src_path = os.path.join(base_dir, src_subdir, filename)
                dest_path = os.path.join(dest_dir, filename)
                
                shutil.copy2(src_path, dest_path)
                split_letter_counts[split_name][letter] += 1
            
            print(f"    {split_name}: {len(file_list)} files")
        
        # Show letter distribution for this graph type
        print(f"  Letter distribution:")
        for split_name in ['train', 'val', 'test']:
            letter_counts = [split_letter_counts[split_name][letter] for letter in sorted(valid_letters)]
            min_count = min(letter_counts) if letter_counts else 0
            max_count = max(letter_counts) if letter_counts else 0
            print(f"    {split_name}: {min_count}-{max_count} files per letter")
    
    # Final summary
    print("\n" + "="*60)
    print("REDISTRIBUTION COMPLETE")
    print("="*60)
    
    print("\nCreated directories:")
    for graph_type in sorted(expected_graph_types):
        graph_dir = os.path.join(base_dir, f"data_{graph_type}")
        if os.path.exists(graph_dir):
            print(f"  {graph_dir}/")
            print(f"    ├── train/processed/")
            print(f"    ├── val/processed/")
            print(f"    └── test/processed/")
    
    print(f"\nEach graph type now has its own 70-15-15 split for performance comparison!")
    print(f"Train separate models on each graph type and compare results.")

if __name__ == "__main__":
    # Set random seed for reproducible splits
    random.seed(42)
    
    print("Starting graph-specific data redistribution...")
    print("Each graph type will get its own 70-15-15 split")
    
    redistribute_by_graph_type()
    
    print("\nRedistribution completed successfully!")
    print("You can now train and compare models for each graph type separately.")